<html>
<head>  
   <link rel="stylesheet" href="https://www.clickdesk.com/assets/plugin-files/bootstrap.min.css">
   <link rel="stylesheet" href="https://www.clickdesk.com/assets/plugin-files/clickdesk.css">
  
	<style type="text/css">
	body{ padding-top:0px !important;}
	</style>


</head>

<body>

<div class="container">
<header>
<br />
<h1 class="ac">Webchat Panel is not active.<br/>
<small>Sorry, it seems that you do not have an account yet. Please setup your ClickDesk account first</small></h1></br/>
</header>

<br /><br />
<div class="ac">
<a href="admin.php?page=livily_dashboard"><button class="btn success huge"> <b>Go to Account Setup</b></button></a>
</div>
</div>
<br />
	
</body>
</html>
